package example.com.vtt;

import android.service.textservice.SpellCheckerService;

/**
 * Created by Sirjan .
 */

public class Spell_ extends SpellCheckerService {

    @Override
    public Session createSession() {
        return null;
    }
}